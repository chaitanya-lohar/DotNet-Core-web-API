﻿using DataAccessLayer;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;
using WebApplication.API.Repositories;

namespace WebApplication.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IEmployeeRepository _employeeRepository;
        public EmployeeController(EmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        [HttpGet]
        public async Task<ActionResult> GetEmployees() {

            try
            {
                return Ok(await _employeeRepository.GetEmployees());
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error in retrieval data from database");
            }

        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Employee?>> GetEmployee(int id)
        {

            try
            {

                var result = await _employeeRepository.GetEmployee(id);

                if (result == null)
                {
                    return NotFound();
                }
                else
                {
                    return result;
                }

            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error in retrieval data from database");
            }
        }

        [HttpPost]
        public async Task<ActionResult<Employee>> CreateEmployee(Employee employee) {

            try
            {
                if (employee == null)
                {
                    return BadRequest();
                }
                else
                {
                    var CreatedEmp = await _employeeRepository.AddEmployee(employee);
                    return CreatedAtAction(nameof(GetEmployee), new { id = CreatedEmp.Id }, CreatedEmp);
                }
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error in inserting data into database");
            }

        }

        [HttpPut("{id:int}")]
        public async Task<ActionResult<Employee?>> UpdateEmployee(int id, Employee employee) {
            try
            {
                if (id != employee.Id) {
                    return BadRequest("Id Mismatched!");
                }

                var updateEmployee = await _employeeRepository.GetEmployee(id);
                if (updateEmployee == null)
                {
                    return NotFound($"Employee id {id} is not found!");
                }

                return await _employeeRepository.UpdateEmployee(employee);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in inserting data into database");
            }


        }

        [HttpDelete("{id:int}")]
        public async Task<ActionResult<Employee?>> DeleteEmployee(int id)
        {

            try
            {
                var deleteEmployee = await _employeeRepository.GetEmployee(id);

                if (deleteEmployee == null)
                {
                    return NotFound($"Employee id {id} is not found!");
                }

                return await _employeeRepository.DeleteEmployee(deleteEmployee.Id);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in deletion of of employee");
            }

        }

        [HttpGet("{search}")]
        public async Task<ActionResult<IEnumerable<Employee>>> Search(string name)
        {

            try
            {
                var result= await _employeeRepository.Search(name);
                if (result.Any())
                {
                    return Ok(result);
                }
                else {
                    return NotFound();
                }
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error in retrieval data from database");
            }
        }

    }
}
