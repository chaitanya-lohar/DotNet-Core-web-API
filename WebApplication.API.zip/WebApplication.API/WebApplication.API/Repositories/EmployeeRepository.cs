﻿using DataAccessLayer;
using Microsoft.EntityFrameworkCore;
using WebApplication.API.DataContext;

namespace WebApplication.API.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly ApplicationDbContext _context;
        public EmployeeRepository(ApplicationDbContext context)  // using this contructor to inilized memory to the object of ApplicationDbContext
        {
            _context = context;
        }

        public async Task<Employee> AddEmployee(Employee employee)
        {
            var result = await _context.Employees.AddAsync(employee);
            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Employee?> DeleteEmployee(int Id)
        {
            var result = await _context.Employees.FindAsync(Id);
            if (result != null) {
                _context.Employees.Remove(result);
                await _context.SaveChangesAsync();
                return result;
            }
            return null;
        }


        public async Task<Employee?> GetEmployee(int Id)
        {
            return await _context.Employees.FirstOrDefaultAsync(x => x.Id == Id);
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
           return await _context.Employees.ToListAsync();
            
        }

        public async Task<IEnumerable<Employee>> Search(string name)
        {
            IQueryable<Employee> query = _context.Employees;
            if (!String.IsNullOrEmpty(name)) {
                query = query.AsNoTracking().Where(x => x.Name.Contains(name));
            }
            return await query.ToListAsync();
        }

        public async Task<Employee?> UpdateEmployee(Employee employee)
        {
            Employee? result = await _context.Employees.FirstOrDefaultAsync(x => x.Id == employee.Id);
            if (result != null)
            {
                result.City = employee.City;
                result.Name = employee.Name;
                await _context.SaveChangesAsync();
                return result;
            }
            return null;
            
        }
    }
}
